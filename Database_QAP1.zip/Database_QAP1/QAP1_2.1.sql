select address_id, address, district, city_id from address


