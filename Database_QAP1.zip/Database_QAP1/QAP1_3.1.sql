INSERT INTO address (address_id, address, address2, district, city_id, postal_code, phone, last_update)
VAlUES (606, '123 Main Street', '', 'California', 177, 366789, 137809745678, '2024-05-20 19:01:23.547');

INSERT INTO customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES 
(600, 1, 'John', 'Doe', 'john.doe@sakilacustomer.org', 606, 'true', '2024-05-10', '2024-05-20 18:49:32.672', 1),
(601, 1, 'Jane', 'Doe', 'jane.doe@sakilacustomer.org', 606, 'true', '2024-05-10', '2024-05-20 18:49:32.672', 1),
(602, 1, 'Jimmy', 'Doe', 'jimmy.doe@sakilacustomer.org', 606, 'true', '2024-05-10', '2024-05-20 18:49:32.672', 1),
(603, 1, 'Jasmine', 'Doe', 'jasmine.doe@sakilacustomer.org', 606, 'true', '2024-05-10', '2024-05-20 18:49:32.672', 1);

select * from customer