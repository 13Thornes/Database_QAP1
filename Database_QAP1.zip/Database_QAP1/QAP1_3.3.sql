DELETE FROM address Where 
address_id = 606

select * from address

