select address_id, address, district, address.city_id 
from address
Inner Join city 
ON address.city_id = city.city_id
where district='West Java'
Group by address_id
Order by city_id





