INSERT INTO address (address_id, address, address2, district, city_id, postal_code, phone, last_update)
VAlUES (607, '987 Waterfront Boulevard', '', 'California', 177, 366767, 137809745678, '2024-05-20 19:01:23.547');

UPDATE customer
SET address_id = 607
Where customer_id = 600;

UPDATE customer
SET address_id = 607
Where customer_id = 601;

UPDATE customer
SET address_id = 607
Where customer_id = 602;

UPDATE customer
SET address_id = 607
Where customer_id = 603;