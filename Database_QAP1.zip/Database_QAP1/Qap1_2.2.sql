select address_id, address, district, city_id from address
where district='West Java'


