CREATE DATABASE RepandCustomer
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

CREATE TABLE public."rep"
(
    	rep_id int,
	first_name varchar(50),
	last_name varchar(50),
	email varchar(50),
	phone varchar(11),
	PRIMARY KEY (rep_id)
);

INSERT INTO rep (rep_id, first_name, last_name, email, phone)
VALUES 
(1, 'Cindy', 'Smith', 'cindy.smith@company.org', 17094356778),
(2, 'Mark', 'Douglas', 'mark.douglas@company.org', 17092164567),
(3, 'John', 'Doe', 'john.doe@company.org', 17097235678),
(4, 'Jeremiah', 'Scott', 'jeremiah.scott@company.org', 17097832321);

CREATE TABLE public."cust"
(
    	cust_id int,
	first_name varchar(50),
	last_name varchar(50),
	email varchar(50),
	phone varchar(11),
	rep_id int,
	PRIMARY KEY (cust_id),
	FOREIGN KEY (rep_id) REFERENCES rep(rep_id)
);

INSERT INTO cust (cust_id, first_name, last_name, email, phone, rep_id)
VALUES 
(1, 'Joan', 'Ark', 'joan.ark@email.com', 17094323253, 1),
(2, 'Harry', 'Henderson', 'harry.henderson@email.com', 17092470023, 2),
(3, 'Jenny', 'Johnson', 'jenny.johnson@email.com', 17092095382, 3),
(4, 'Kara', 'King', 'kara.king@email.com', 17092981573, 4),
(5, 'Sarah', 'Swan', 'sarah.swan@email.com', 17092345678, 1),
(6, 'Jeremy', 'Pond', 'jeremy.pond@email.com', 17091234567, 2),
(7, 'Shelby', 'Peckford', 'shelby.peckford@email.com', 17094567890, 3),
(8, 'Liam', 'Avery', 'liam.avery@email.com', 17095678901, 4);




